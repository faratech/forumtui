WindowsForum TUI (wftui) 0.0.1 — linux-aarch64

Terminal client for windowsforum.com. Run ./wftui, or copy it onto your
PATH (e.g. /usr/local/bin/wftui).

Proprietary software — in development. Not for redistribution.
https://windowsforum.com
